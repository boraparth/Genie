package com.example.droidrush;

public class People {
    String name,
            email;
    People(String name){
        this.name=name;
    }
}
