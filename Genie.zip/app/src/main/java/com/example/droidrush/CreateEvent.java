package com.example.droidrush;

import android.app.DatePickerDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import com.example.droidrush.People;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;
import java.util.UUID;

public class CreateEvent extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_event);
        People p1=new People("Parth");
        Log.d("Name: ",p1.name);


    }

    public void goEventPage(View view) {

        String eventDomain=((EditText)findViewById(R.id.event_domain)).getText().toString();
        String eventName=((EditText)findViewById(R.id.event_name)).getText().toString();
        if(TextUtils.isEmpty(eventName))
            return;
        String path="EVENTS/"+eventDomain+"/"+eventName;
        DatabaseReference event=FirebaseDatabase.getInstance().getReference(path);
        event.child("ADMIN").setValue(FirebaseAuth.getInstance().getCurrentUser().getUid().toString());
    }

    public void pickDate(View view) {
        Calendar c=Calendar.getInstance();
        DatePickerDialog datePickerDialog=new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        ((EditText)findViewById(R.id.event_date)).setText(dayOfMonth+"/"+(month+1)+"/"+year);
                    }
                },c.get(Calendar.YEAR),c.get(Calendar.MONTH),Calendar.DAY_OF_MONTH);
        datePickerDialog.show();
    }
}
