package com.example.droidrush;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class SignIn extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
    }


    public void signUp(View view) {
            startActivity(new Intent(this,SignUp.class));
    }

    public void login(View view) {


        final TextView signInNote=(TextView)findViewById(R.id.signInNote);
        final ProgressBar signInProgBar=(ProgressBar)findViewById(R.id.signInProgBar);

        final EditText signInMail=(EditText)findViewById(R.id.signInEmail);
        final EditText signInPass=(EditText)findViewById(R.id.signInPass);

        signInNote.setVisibility(View.INVISIBLE);


        String mail=signInMail.getText().toString().trim();
        String pass=signInPass.getText().toString().trim();

        if(TextUtils.isEmpty(mail) || TextUtils.isEmpty(pass)){
            signInNote.setText("Enter all detail");
            signInNote.setVisibility(View.VISIBLE);
            return;
        }

        signInProgBar.setVisibility(View.VISIBLE);

        FirebaseAuth mAuth=FirebaseAuth.getInstance();
        mAuth.signInWithEmailAndPassword(mail,pass)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            startActivity(new Intent(getApplicationContext(),Home.class));
                        } else {
                            signInProgBar.setVisibility(View.INVISIBLE);
                            signInNote.setVisibility(View.VISIBLE);
                            String error=task.getException().toString();
                            signInNote.setText(error.substring(error.indexOf(":")+1));
                        }

                    }
                });
    }
}
