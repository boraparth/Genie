package com.example.droidrush;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class SignUp extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        if(FirebaseAuth.getInstance().getCurrentUser()!=null)
            startActivity(new Intent(this, Home.class));
    }

    public void goProfile(View view) {
        final EditText signUpName=(EditText)findViewById(R.id.signUpName);
        final EditText signUpMail=(EditText)findViewById(R.id.signUpEmail);
        final EditText signUpPass=(EditText)findViewById(R.id.signUpPass);
        final TextView signUpNote=(TextView)findViewById(R.id.signUpNote);
        final ProgressBar signUpProgBar=(ProgressBar)findViewById(R.id.signUpProgBar);


        signUpNote.setVisibility(View.INVISIBLE);

        final String name=signUpName.getText().toString();
        String mail=signUpMail.getText().toString().trim();
        String pass=signUpPass.getText().toString().trim();
        if(TextUtils.isEmpty(name) || TextUtils.isEmpty(mail) || TextUtils.isEmpty(pass)){
            signUpNote.setText("Enter all details");
            signUpNote.setVisibility(View.VISIBLE);
            return;
        }
        signUpProgBar.setVisibility(View.VISIBLE);

        final FirebaseAuth mAuth= FirebaseAuth.getInstance();
        mAuth.createUserWithEmailAndPassword(mail,pass)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            FirebaseDatabase.getInstance().getReference("people").child(mAuth.getCurrentUser().getUid().toString()).child("NAME").setValue(name);
                            startActivity(new Intent(getApplicationContext(),Home.class));
                        } else {
                            signUpProgBar.setVisibility(View.INVISIBLE);
                            signUpNote.setVisibility(View.VISIBLE);
                            String error=task.getException().toString();
                            signUpNote.setText(error.substring(error.indexOf(":")+1));
                        }
                    }
                });
    }

    @Override
    public void onBackPressed(){}

    public void signIn(View view) {
        startActivity(new Intent(this,SignIn.class));
    }
}
